import React, { useState, useEffect, useCallback } from 'react';
import * as XLSX from 'xlsx';
import './App.css';

// ── Initial seed data ──────────────────────────────────────────────────────
const SEED_STUDENTS = [
  { id: 1, name: 'Alice Johnson',   email: 'alice@uni.edu',   age: 21 },
  { id: 2, name: 'Bob Martinez',    email: 'bob@uni.edu',     age: 23 },
  { id: 3, name: 'Carol Williams',  email: 'carol@uni.edu',   age: 20 },
  { id: 4, name: 'David Lee',       email: 'david@uni.edu',   age: 22 },
  { id: 5, name: 'Eva Patel',       email: 'eva@uni.edu',     age: 24 },
];

let nextId = 6;

// ── Helpers ────────────────────────────────────────────────────────────────
const isValidEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function validate(form) {
  const errs = {};
  if (!form.name.trim())            errs.name  = 'Name is required.';
  if (!form.email.trim())           errs.email = 'Email is required.';
  else if (!isValidEmail(form.email)) errs.email = 'Enter a valid email.';
  if (!form.age)                    errs.age   = 'Age is required.';
  else if (isNaN(form.age) || +form.age < 1 || +form.age > 120)
                                    errs.age   = 'Age must be 1–120.';
  return errs;
}

// ── Sub-components ──────────────────────────────────────────────────────────

function Spinner() {
  return (
    <div className="spinner-wrap">
      <div className="spinner" />
      <span>Loading students…</span>
    </div>
  );
}

function Toast({ msg, type, onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3200);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div className={`toast toast--${type}`}>
      <span className="toast-icon">{type === 'success' ? '✓' : '✕'}</span>
      {msg}
    </div>
  );
}

function Modal({ title, children, onClose }) {
  useEffect(() => {
    const fn = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, [onClose]);
  return (
    <div className="overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="icon-btn close-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function StudentForm({ initial, onSubmit, onCancel, loading }) {
  const blank = { name: '', email: '', age: '' };
  const [form, setForm]   = useState(initial || blank);
  const [errs, setErrs]   = useState({});
  const [dirty, setDirty] = useState(false);

  const handle = (field) => (e) => {
    setForm((f) => ({ ...f, [field]: e.target.value }));
    setDirty(true);
    if (errs[field]) setErrs((er) => ({ ...er, [field]: '' }));
  };

  const submit = async (e) => {
    e.preventDefault();
    const v = validate(form);
    if (Object.keys(v).length) { setErrs(v); return; }
    await onSubmit({ ...form, age: +form.age });
  };

  return (
    <form className="student-form" onSubmit={submit} noValidate>
      {['name', 'email', 'age'].map((field) => (
        <div className="field" key={field}>
          <label htmlFor={`f-${field}`}>
            {field.charAt(0).toUpperCase() + field.slice(1)}
            <span className="required">*</span>
          </label>
          <input
            id={`f-${field}`}
            type={field === 'email' ? 'email' : field === 'age' ? 'number' : 'text'}
            value={form[field]}
            onChange={handle(field)}
            placeholder={field === 'name' ? 'Full name' : field === 'email' ? 'you@example.com' : '18'}
            className={errs[field] ? 'input--error' : ''}
            min={field === 'age' ? 1 : undefined}
            max={field === 'age' ? 120 : undefined}
          />
          {errs[field] && <span className="error-msg">{errs[field]}</span>}
        </div>
      ))}
      <div className="form-actions">
        <button type="button" className="btn btn--ghost" onClick={onCancel} disabled={loading}>
          Cancel
        </button>
        <button type="submit" className="btn btn--primary" disabled={loading || !dirty}>
          {loading ? <span className="btn-spinner" /> : null}
          {initial ? 'Save Changes' : 'Add Student'}
        </button>
      </div>
    </form>
  );
}

function DeleteConfirm({ student, onConfirm, onCancel, loading }) {
  return (
    <div className="delete-confirm">
      <div className="delete-icon">⚠</div>
      <p>
        Are you sure you want to delete <strong>{student.name}</strong>?<br />
        <span className="text-dim">This action cannot be undone.</span>
      </p>
      <div className="form-actions">
        <button className="btn btn--ghost" onClick={onCancel} disabled={loading}>Cancel</button>
        <button className="btn btn--danger" onClick={onConfirm} disabled={loading}>
          {loading ? <span className="btn-spinner" /> : null}
          Yes, Delete
        </button>
      </div>
    </div>
  );
}

// ── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const [students,  setStudents]  = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [sortBy,    setSortBy]    = useState('id');
  const [sortDir,   setSortDir]   = useState('asc');
  const [modal,     setModal]     = useState(null); // null | 'add' | 'edit' | 'delete'
  const [target,    setTarget]    = useState(null);
  const [submitting,setSubmitting]= useState(false);
  const [toast,     setToast]     = useState(null);
  const [page,      setPage]      = useState(1);
  const PER_PAGE = 5;

  // Simulate initial data load
  useEffect(() => {
    sleep(900).then(() => {
      setStudents(SEED_STUDENTS);
      setLoading(false);
    });
  }, []);

  const showToast = useCallback((msg, type = 'success') => {
    setToast({ msg, type, id: Date.now() });
  }, []);

  // ── Sorting
  const toggleSort = (col) => {
    if (sortBy === col) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortBy(col); setSortDir('asc'); }
    setPage(1);
  };

  // ── Filtered + sorted data
  const filtered = students
    .filter((s) => {
      const q = search.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        String(s.age).includes(q)
      );
    })
    .sort((a, b) => {
      const av = sortBy === 'age' ? +a[sortBy] : String(a[sortBy]).toLowerCase();
      const bv = sortBy === 'age' ? +b[sortBy] : String(b[sortBy]).toLowerCase();
      return sortDir === 'asc' ? (av > bv ? 1 : -1) : av < bv ? 1 : -1;
    });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const paginated  = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  // ── CRUD handlers
  const handleAdd = async (data) => {
    setSubmitting(true);
    await sleep(600);
    setStudents((prev) => [...prev, { ...data, id: nextId++ }]);
    setSubmitting(false);
    setModal(null);
    showToast(`${data.name} added successfully.`);
  };

  const handleEdit = async (data) => {
    setSubmitting(true);
    await sleep(600);
    setStudents((prev) => prev.map((s) => (s.id === target.id ? { ...s, ...data } : s)));
    setSubmitting(false);
    setModal(null);
    showToast(`${data.name} updated successfully.`);
  };

  const handleDelete = async () => {
    setSubmitting(true);
    await sleep(600);
    setStudents((prev) => prev.filter((s) => s.id !== target.id));
    setSubmitting(false);
    setModal(null);
    showToast(`${target.name} deleted.`, 'error');
  };

  // ── Excel export
  const exportExcel = () => {
    const rows = filtered.map(({ name, email, age }) => ({ Name: name, Email: email, Age: age }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Students');
    XLSX.writeFile(wb, `students_${new Date().toISOString().slice(0, 10)}.xlsx`);
    showToast(`Exported ${rows.length} row${rows.length !== 1 ? 's' : ''} to Excel.`);
  };

  // ── Sort indicator
  const SortIcon = ({ col }) => {
    if (sortBy !== col) return <span className="sort-icon neutral">⇅</span>;
    return <span className="sort-icon active">{sortDir === 'asc' ? '↑' : '↓'}</span>;
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <div className="logo-mark">S</div>
          <div>
            <h1 className="app-title">Students</h1>
            <p className="app-sub">Management Console</p>
          </div>
        </div>
        <div className="header-right">
          <span className="badge">{students.length} total</span>
        </div>
      </header>

      <main className="app-main">
        {/* Controls bar */}
        <div className="controls">
          <div className="search-wrap">
            <span className="search-icon">⌕</span>
            <input
              className="search-input"
              placeholder="Search by name, email or age…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
            {search && (
              <button className="clear-btn" onClick={() => { setSearch(''); setPage(1); }}>✕</button>
            )}
          </div>
          <div className="ctrl-actions">
            <button className="btn btn--outline" onClick={exportExcel} disabled={filtered.length === 0}>
              <span>⬇</span> Export Excel
            </button>
            <button className="btn btn--primary" onClick={() => setModal('add')}>
              <span>+</span> Add Student
            </button>
          </div>
        </div>

        {/* Stats strip */}
        <div className="stats-strip">
          <span className="stat">
            <span className="stat-num">{filtered.length}</span>
            <span className="stat-label">matching</span>
          </span>
          <span className="stat-divider" />
          <span className="stat">
            <span className="stat-num">{page}/{totalPages}</span>
            <span className="stat-label">page</span>
          </span>
          {search && (
            <>
              <span className="stat-divider" />
              <span className="stat stat--filter">
                Filtered: <em>"{search}"</em>
              </span>
            </>
          )}
        </div>

        {/* Table */}
        <div className="table-wrap">
          {loading ? (
            <Spinner />
          ) : (
            <>
              <table className="students-table">
                <thead>
                  <tr>
                    {[['name','Name'],['email','Email'],['age','Age']].map(([col, label]) => (
                      <th key={col} onClick={() => toggleSort(col)} className="sortable">
                        {label} <SortIcon col={col} />
                      </th>
                    ))}
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="empty-row">
                        <div className="empty-state">
                          <span className="empty-icon">◈</span>
                          <p>No students found{search ? ` for "${search}"` : ''}.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    paginated.map((s, i) => (
                      <tr key={s.id} style={{ animationDelay: `${i * 40}ms` }} className="student-row">
                        <td>
                          <div className="name-cell">
                            <span className="avatar">{s.name[0]}</span>
                            {s.name}
                          </div>
                        </td>
                        <td className="mono">{s.email}</td>
                        <td><span className="age-pill">{s.age}</span></td>
                        <td>
                          <div className="action-btns">
                            <button
                              className="icon-btn edit-btn"
                              onClick={() => { setTarget(s); setModal('edit'); }}
                              title="Edit"
                            >✎</button>
                            <button
                              className="icon-btn del-btn"
                              onClick={() => { setTarget(s); setModal('delete'); }}
                              title="Delete"
                            >⊗</button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="pagination">
                  <button
                    className="btn btn--ghost btn--sm"
                    disabled={page === 1}
                    onClick={() => setPage(1)}
                  >«</button>
                  <button
                    className="btn btn--ghost btn--sm"
                    disabled={page === 1}
                    onClick={() => setPage((p) => p - 1)}
                  >‹</button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
                    <button
                      key={n}
                      className={`btn btn--sm ${n === page ? 'btn--primary' : 'btn--ghost'}`}
                      onClick={() => setPage(n)}
                    >{n}</button>
                  ))}
                  <button
                    className="btn btn--ghost btn--sm"
                    disabled={page === totalPages}
                    onClick={() => setPage((p) => p + 1)}
                  >›</button>
                  <button
                    className="btn btn--ghost btn--sm"
                    disabled={page === totalPages}
                    onClick={() => setPage(totalPages)}
                  >»</button>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Modals */}
      {modal === 'add' && (
        <Modal title="Add New Student" onClose={() => !submitting && setModal(null)}>
          <StudentForm
            onSubmit={handleAdd}
            onCancel={() => setModal(null)}
            loading={submitting}
          />
        </Modal>
      )}
      {modal === 'edit' && target && (
        <Modal title="Edit Student" onClose={() => !submitting && setModal(null)}>
          <StudentForm
            initial={target}
            onSubmit={handleEdit}
            onCancel={() => setModal(null)}
            loading={submitting}
          />
        </Modal>
      )}
      {modal === 'delete' && target && (
        <Modal title="Confirm Deletion" onClose={() => !submitting && setModal(null)}>
          <DeleteConfirm
            student={target}
            onConfirm={handleDelete}
            onCancel={() => setModal(null)}
            loading={submitting}
          />
        </Modal>
      )}

      {/* Toast */}
      {toast && (
        <Toast
          key={toast.id}
          msg={toast.msg}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
