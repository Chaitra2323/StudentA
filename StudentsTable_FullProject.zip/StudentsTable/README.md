# 📚 Students Table — React.js Full Stack Assignment

A production-quality **Students Table Management App** built with React.js.
All CRUD operations are handled in-memory on the frontend (no backend required).

---

## ✨ Features

| Feature | Details |
|---|---|
| **Student List** | Name, Email, Age, Actions (Edit / Delete) |
| **Add Student** | Form with full validation (required fields + email format) |
| **Edit Student** | Pre-filled form with same validations |
| **Delete Student** | Confirmation dialog before deletion |
| **Search / Filter** | Real-time search across name, email, age |
| **Sort** | Click any column header to sort asc/desc |
| **Pagination** | 5 rows per page, navigable |
| **Loading State** | Simulated 900ms spinner on initial load |
| **Excel Export** | Downloads filtered (or full) data as `.xlsx` via SheetJS |
| **Toast Notifications** | Success/error feedback on every action |
| **Responsive Design** | Works on mobile & desktop |

---

## 🚀 Getting Started

### Prerequisites
- **Node.js** v18+ and **npm** v9+

### Installation & Run

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm start
```

App runs at **http://localhost:3000**

### Production Build

```bash
npm run build
```

Outputs optimised static files to `build/` folder — ready to deploy.

---

## 📦 Deployment

### Vercel (Recommended)

```bash
npm install -g vercel
vercel --prod
```

### Netlify

```bash
npm run build
# Drag-and-drop the 'build/' folder at netlify.com/drop
```

---

## 🗂 Project Structure

```
StudentsTable/
├── public/
│   └── index.html
├── src/
│   ├── App.js          # Main app – all CRUD logic & components
│   ├── App.css         # Full design system & animations
│   ├── index.js        # React entry point
│   └── index.css       # CSS variables & global styles
├── StudentsTable/
│   └── StudentsTable.csproj   # VS project file
├── StudentsTable.sln   # Visual Studio Solution file
├── package.json
└── README.md
```

---

## 🛠 Tech Stack

- **React 18** — Functional components + Hooks
- **SheetJS (xlsx)** — Excel export
- **CSS Custom Properties** — Design system
- **In-memory state** — All data managed via `useState`

---

## 🎁 Optional Backend (Bonus)

To add a NestJS + PostgreSQL backend:

```bash
npm install -g @nestjs/cli
nest new students-backend
cd students-backend
npm install @nestjs/typeorm typeorm pg
```

Create a `Student` entity and REST endpoints (`GET /students`, `POST /students`, `PATCH /students/:id`, `DELETE /students/:id`).

---

## 📋 Validation Rules

- **Name** — Required, non-empty string
- **Email** — Required, valid format (`user@domain.tld`)
- **Age** — Required, integer between 1 and 120

---

## 📝 License

MIT — Free to use, modify, and distribute.
